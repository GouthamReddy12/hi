## Dec 7, 2015
- Update java-cloudant client to version 2.0.0

## Nov 16, 2015
- Added changelog